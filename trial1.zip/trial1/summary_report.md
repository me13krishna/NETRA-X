# NETRA-X Scraping & Extraction Report — Trial 1

**Target URL**: `https://info.cern.ch/LMBrowser.html`  
**Ingestion Timestamp**: `2026-08-31T14:21:24Z`  
**Cryptographic Hash**: `SHA-256:7d7ce623b11fd19ff226f82f3f438bfaa00069a80a9a9ea5fb84e632533c9515`  
**Lawful Basis**: `PASSIVE_OSINT`  

---

## 1. Provenance & Artifact Metadata
- **Raw Bytes Collected**: `4163 bytes`
- **WARC Digest**: `7d7ce623b11fd19ff226f82f3f438bfaa00069a80a9a9ea5fb84e632533c9515`
- **WARC Record File**: [`trial1/warc_record.warc`](file:///C:/Users/Laxmi Mishra/OneDrive/Desktop/NETRA-X/trial1/warc_record.warc)

---

## 2. Extracted Entities & Identifiers
- **Emails Found**: `['web.communications@cern.ch']`
- **BTC Wallets Found**: `[]`
- **PGP Fingerprints Found**: `[]`
- **Onion Services**: `[]`
- **Monero Abstention**: `False`

---

## 3. SHA-256 Audit Verification
Cryptographic audit record saved to [`trial1/sha256_audit.json`](file:///C:/Users/Laxmi Mishra/OneDrive/Desktop/NETRA-X/trial1/sha256_audit.json).
